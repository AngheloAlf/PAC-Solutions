<?php
//Los datos para logearse en la base de datos
$SQLhost = "localhost";
$SQLusuario = "root";
$SQLpass = "mono";
$SQLname = 'OSI';
?>
