<?php
$hostPage = "http://localhost/WebPage/"; //poner la direccion de valpo interviene aca
$permiteCuentas = true;
?>