<header>
	<img src="resources/Baseline.svg" width=100%>
	<br>


       
          
		<?php include 'topnav.php'; ?>



		<?php
		if(!$_SESSION["js"]){
			echo "<br><h6>Su navegador parece no ser compatible con JavaScript.<br> Puede que algunas caracteristicas de esta pagina no funcionen como deberian.</h6>";
		}
		?>

</header>