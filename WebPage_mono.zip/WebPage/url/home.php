<!DOCTYPE html>
<html>
	<body  style="background-color:#F2F5F8">
	<div class="row" style="padding-top:2%">
    <div class="large-12 columns">
        <div class="panel">
            <center>
            <h1>Prototípo Funcional</h1>
            </center>
        </div>
    </div>
    </div>
    </body>
</html>
