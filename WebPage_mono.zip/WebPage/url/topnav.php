<div height=300 width=100% style="background-color:#333333"  >
        <nav class="top-bar" data-topbar role="navigation" style="height:20%;width:100%; padding-left:15%">
          <ul class="title-area">
            <li class="name">
              <h1><a href="/"><img src="resources/valpo.svg" height="150" width="150" ></a></h1>
            </li>
          </ul>
          <section class="top-bar-section" style="padding-top:1%;padding-right:10%;padding-left:10%">
            <ul class="left">
            <li>
				<a href="?page=home">Inicio</a></li>
			<li>
				<a href="?page=actualizarPunto">Indicar estado del punto limpio</a></li>
				<li>
				<a href="?page=listaPuntos">Puntos Limpios</a></li>
				<li>
				<a href="?page=solicitudComunidad">Solicitud Junta de Vecinos</a></li>
				<li>
				<a href="?page=admin">Login Admin</a></li>
			  </ul>
          </section>
        </nav>
</div>