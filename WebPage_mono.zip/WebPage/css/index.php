<?php
include_once("commonR.php");
redireccionarAR("../?page=404");
?>