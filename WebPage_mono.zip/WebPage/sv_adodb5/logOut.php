<?php
unset($_SESSION["user_admin"]);
header("Location: index.php");
?>
