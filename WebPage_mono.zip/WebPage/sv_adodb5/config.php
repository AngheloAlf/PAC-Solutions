<?php
//datos para wrapper
include("adodb5/adodb.inc.php");
$driver= 'mysqli';
//Los datos para logearse en la base de datos
$SQLhost = "localhost";
$SQLusuario = "root";
$SQLpass = "";
$SQLname = 'OSI';
?>
