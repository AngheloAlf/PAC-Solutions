<br>
<footer class="footer text-center" >
	<div class="navbar navbar-default navbar-fixed-bottom">
		<div class="container">
			<p class="navbar-text">
				<i>Created by PAC Solutions</i>
			</p>
		</div>
	</div>
</footer>
